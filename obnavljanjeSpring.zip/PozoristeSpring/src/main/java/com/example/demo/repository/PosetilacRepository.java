package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Posetilac;

public interface PosetilacRepository extends JpaRepository<Posetilac, Integer> {

}