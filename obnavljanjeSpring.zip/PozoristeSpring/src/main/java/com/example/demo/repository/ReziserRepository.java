package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import model.Reziser;

public interface ReziserRepository extends JpaRepository<Reziser, Integer>{

}